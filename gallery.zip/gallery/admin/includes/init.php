<?php

include("new_config.php");
include("database.php");


 ?>