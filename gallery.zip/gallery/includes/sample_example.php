First we have a simple Database class,that establishes connection (via constructor,it calls the method that establishes connection):

<?php
/**
 * Class Database
 */
class Database
{
    
    /**
     * @var \PDO
     */
    private $pdo;
    
    /**
     * @var string
     */
    private $host   = 'localhost';
    
    /**
     * @var string
     */
    private $dbName = 'demo';
    
    /**
     * @var string
     */
    private $user   = 'root';
    
    /**
     * @var string
     */
    private $pass   = '';
    
    /**
     * Database constructor.
     */
    public function __construct()
    {
        try {
            $this->initateConnection();
        } catch(PDOException $e) {
            die('Error connecting to a database: ' . $e->getMessage());
        }
    }
    
    /**
     * Initiates connections through PDO.
     *
     * @return void
     */
    private function initateConnection()
    {
        
        $dsn = "mysql:host={$this->host};dbname={$this->dbName}";
        
        $this->pdo = new PDO($dsn, "{$this->user}", "{$this->pass}");
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    
    /**
     * Retrieves PDO instance.
     *
     * @return \PDO
     */
    public function PDO()
    {
        
        return $this->pdo;
    }
}
And then we have a User class,that simply uses database object (instance of Database class) as depedency injection:

/**
 * Class User
 *
 * A simple class that demonstrates the usage of dependency injection.
 */
class User
{
    
    /**
     * @var \PDO
     */
    private $pdo;
    
    /**
     * User constructor.
     *
     * Injects depedency - PDO Database connection.
     *
     * @param \Database $database
     */
    public function __construct(Database $database)
    {
        
        $this->pdo = $database;
    }
    
}
The usage would be this:

$user = new User(new Database());
?>
And that's it.

Note that this is very basic example,very basic. We are instantiating User class,and we are passing it's dependency, Database object. That's the concept. Dependency injection can be also done by method, here we are using constructor,but we could also use regular method for that purpose.

I hope that this illustrates enough for you to understand what is dependency injection, and how to connect to a database via contructor,as you see in a Database class.